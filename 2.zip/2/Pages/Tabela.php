	<table>
			<tr>
				<th>Nome</th>
				<th>Email</th>
				<th>Assunto</th>
				<th>Mensagen</th>

			</tr>
			<?php foreach($lista_contatos as $contato): ?>
			<tr>
				<td><?php echo $contato['Nome']; ?></td>
				<td><?php echo $contato['email']; ?></td>
				<td><?php echo $contato['assunto']; ?></td>
				<td><?php echo $contato['mensagem']; ?></td>
			</tr>
			<?php endforeach; ?>
</table>
