<?php

	include "bancoContato.php";

buscar($conexao,$contato);

	if(isset($_POST['Nome']) && ($_POST['Nome'] != '')){
		$contato= array();
		$contato['Nome']=$_POST['Nome'];

		if(isset($_POST['email'])){
			$contato['email']=$_POST['email'];
		}else{
			$contato['email']= '';
		}

		if(isset($_POST['assunto'])){
			$contato['assunto']=$_POST['assunto'];
		}else{
			$contato['assunto']= '';
		}

    if(isset($_POST['mensagem'])){
      $contato['mensagem']=$_POST['mensagem'];
    }else{
      $contato['mensagem']= '';
    }


		buscar($conexao,$contato);
	}
	include"Contato.html";
?>
