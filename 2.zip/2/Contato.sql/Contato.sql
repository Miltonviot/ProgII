-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 20-Jul-2017 às 15:20
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Contato`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `Contato`
--

CREATE TABLE `Contato` (
  `ID` int(11) NOT NULL,
  `Nome` varchar(150) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `assunto` varchar(50) DEFAULT NULL,
  `mensagem` varchar(8000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `Contato`
--

INSERT INTO `Contato` (`ID`, `Nome`, `email`, `assunto`, `mensagem`) VALUES
(1, 'Teste 1', 'Teste 1', 'Teste 1', 'Teste 1'),
(2, 'Teste', 'teste@hotmail.com', 'teste2', 'teste 2'),
(3, 'teste 333', 'teste333@gmail.com', 'testaaa', 'NÃ£o ? sim ? ; : Ãº'),
(4, 'teste 333', 'teste333@gmail.com', 'testaaa', 'NÃ£o ? sim ? ; : Ãº'),
(5, 'teste 333', 'teste333@gmail.com', 'testaaa', 'NÃ£o ? sim ? ; : Ãº'),
(6, 'kk', '', '', ''),
(7, 'Zappe', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Contato`
--
ALTER TABLE `Contato`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Contato`
--
ALTER TABLE `Contato`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
