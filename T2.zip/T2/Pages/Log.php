<?php
include "bancoContato.php";

$Nome = 'Zappe';
$Senha = 'Zappe';

if ($Nome == $_POST['Nome'] && $Senha == $_POST['Senha'])
  include"MostraContato.php";
  else {
    echo "Erro de Log";
  }
?>
