<?php
	$bdServidor = '127.0.0.1';
	$bdUsuario = 'Zappe';
	$bdSenha = 'Zappe';
	$bdBanco = 'Contato';

	$conexao= mysqli_connect($bdServidor, $bdUsuario, $bdSenha, $bdBanco);

	if (mysqli_connect_errno($conexao))	{
		echo "Problemas	para conectar o banco. Erro: ";
		echo mysqli_connect_error();
		die();
	}

  	function gravar($conexao,$Contato){

  		$sqlInsert = "INSERT INTO
  			Contato(Nome,email,assunto,mensagem)
  			VALUES ('{$Contato['Nome']}',
  							'{$Contato['email']}',
                '{$Contato['assunto']}',
  							'{$Contato['mensagem']}')";
  		mysqli_query($conexao,$sqlInsert);
  	}

		function buscar($conexao){
		$sqlBusca = 'SELECT * FROM Contato';
		$resultado = mysqli_query($conexao,	$sqlBusca);
		$Contatos = [];
		while ($Contatos = mysqli_fetch_assoc($resultado)) {
			$Contatos[] = $contato;
		}
		return $Contatos;
	}




?>
