<?php
include "bancoMostra.php"

$lista_contatos = buscar($conexao);

$contato = array(

    'Nome' => (isset($_POST['Nome'])) ? $_POST['Nome'] : '',
    'email' => (isset($_POST['email'])) ? $_POST['email'] : '',
    'assunto' => (isset($_POST['assunto'])) ? $_POST['assunto'] : '',
    'mensagem' => (isset($_POST['mensagem'])) ? $_POST['mensagem'] : ''

    );
    include "tabela.php"
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mostrar Contato</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link type="text/css" rel="stylesheet" href ="../CSS/Contato.css"/>
    <meta name ="description" content="Atua no Ramo de Grãos,compra e venda de cereais,localizada em Chapecó-SC Fone(49)3329-7656"/>
    <meta name ="keywords" content="cereais,alimentos,venda,feijão,compra,Chapecó,cerealista,grãos"/>
    <meta name ="author" content="Milton Junior Viot UFFS 2017"/>
  </head>

  <body>
    <header>

    </header>
    <nav class="col-3 menu">
      <ul>
        <li><a href="../Index.html">Home</a></li>
        <li><a href="../Pages/Contato.html"target="_blank">Contato</a></li>
        <li><a href="../Pages/Informações.html"target="_blank">Informações</a></li>
        <li><a href="../Pages/QuemSomos.html"target="_blank">Quem Somos</a></li>
        <li><a href="../Pages/Noticias.html"target="_blank">Noticias</a></li>
        <li><a href="../Pages/ListaDePreços.html"target="_blank">Lista de Preços</a></li>
        <li><a href="../Pages/Log.html"target="_blank">Acesso do ADM</a></li>
      </ul>
    </nav>
    <div id="MostraContato">
			<table>
					<tr>
						<th>Nome</th>
						<th>Email</th>
						<th>Assunto</th>
						<th>Mensagen</th>

					</tr>

					<tr>
						<td> </td>
						<td> </td>
						<td> </td>
						<td> </td>
					</tr>

		</table>




		</div>

    <footer>Fale Conosco: e-mail Viot.com@hotmail.com Rua Ary de Carvalho Porto, 493, D, Universitário, Chapecó - SC, CEP: 89812-188  Fone (49)3329-7656</footer>
	</body>
</html>
