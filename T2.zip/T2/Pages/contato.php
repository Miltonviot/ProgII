<?php

	include "bancoContato.php";

buscar($conexao,$Contato);

	if(isset($_POST['Nome']) && ($_POST['Nome'] != '')){
		$Contato= array();
		$Contato['Nome']=$_POST['Nome'];

		if(isset($_POST['email'])){
			$Contato['email']=$_POST['email'];
		}else{
			$Contato['email']= '';
		}

		if(isset($_POST['assunto'])){
			$Contato['assunto']=$_POST['assunto'];
		}else{
			$Contato['assunto']= '';
		}

    if(isset($_POST['mensagem'])){
      $Contato['mensagem']=$_POST['mensagem'];
    }else{
      $Contato['mensagem']= '';
    }


		buscar($conexao,$Contato);
	}
	include"Contato.html";
?>
